package com.example.hotelmanagment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WhatsCookingApplicationTests {

	@Test
	void contextLoads() {
	}

}
